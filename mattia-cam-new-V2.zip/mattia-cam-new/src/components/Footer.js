import './Footer.css';

function Footer(){

  return(
    <div className="footer mt-5 d-flex align-items-center justify-content-center" style={{height: 60}}>
      <h6>Footer application</h6>
    </div>
  )
}

export default Footer;
